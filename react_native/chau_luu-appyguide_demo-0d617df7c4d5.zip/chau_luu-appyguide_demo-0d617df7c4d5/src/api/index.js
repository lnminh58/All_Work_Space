import User from './user';

export default {
  User
};
