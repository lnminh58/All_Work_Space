import { StyleSheet } from 'react-native';

const themeStyles = StyleSheet.create({
});

export default themeStyles;
