const fr = {};

export default fr;
