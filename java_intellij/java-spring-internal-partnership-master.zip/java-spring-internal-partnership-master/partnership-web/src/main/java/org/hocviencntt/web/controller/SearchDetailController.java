package org.hocviencntt.web.controller;

public class SearchDetailController {

}
