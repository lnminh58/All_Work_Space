package org.hocviencntt.rating.service;

import org.springframework.stereotype.Service;

@Service
public class RatingServiceImpl implements RatingService{

}
