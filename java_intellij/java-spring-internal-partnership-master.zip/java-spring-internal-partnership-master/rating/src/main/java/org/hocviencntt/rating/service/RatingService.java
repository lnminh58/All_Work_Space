package org.hocviencntt.rating.service;

public interface RatingService {

}
