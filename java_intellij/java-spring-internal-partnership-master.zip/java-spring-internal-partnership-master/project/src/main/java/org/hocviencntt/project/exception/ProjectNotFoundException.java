package org.hocviencntt.project.exception;

public class ProjectNotFoundException {

}
