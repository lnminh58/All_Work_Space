package org.hocviencntt.user.service;

import org.hocviencntt.user.model.Profile;

public interface ProfileService {
	
//	public Profile loadProfile(String username);
	
}
