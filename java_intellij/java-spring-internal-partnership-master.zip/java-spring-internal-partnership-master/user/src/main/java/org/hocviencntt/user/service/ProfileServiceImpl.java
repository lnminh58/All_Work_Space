package org.hocviencntt.user.service;

import org.hocviencntt.user.model.Profile;
import org.hocviencntt.user.repository.ProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class ProfileServiceImpl implements ProfileService{
//
//	@Autowired
//	private ProfileRepository profileRepository;
//
//	public Profile loadProfile(String username) {
//		return profileRepository.findOne(username);
//	}
//	
	

}
