package org.hocviencntt.user.service;

public interface RoleService {

}
