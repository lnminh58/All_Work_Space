package guru.tour.service;

import java.util.List;

import guru.tour.entity.ProfileEntity;

public interface HostDetailManager {
	public List<ProfileEntity> getAllHost();
}
