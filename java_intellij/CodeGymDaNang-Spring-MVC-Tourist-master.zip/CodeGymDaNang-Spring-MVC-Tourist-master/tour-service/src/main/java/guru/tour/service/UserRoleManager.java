package guru.tour.service;

public interface UserRoleManager {
	void saveUserRole(String roleId,String userId);
}
