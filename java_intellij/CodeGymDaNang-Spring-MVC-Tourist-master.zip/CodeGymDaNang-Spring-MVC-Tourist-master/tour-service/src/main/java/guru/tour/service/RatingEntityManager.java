package guru.tour.service;

import java.util.List;

import guru.tour.entity.RatingEntity;

public interface RatingEntityManager {
	public List<RatingEntity> getAll();
}
