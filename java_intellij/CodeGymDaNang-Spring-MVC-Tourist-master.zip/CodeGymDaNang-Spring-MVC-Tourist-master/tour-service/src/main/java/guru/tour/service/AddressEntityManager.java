package guru.tour.service;

import java.util.List;

import guru.tour.entity.AddressEntity;

public interface AddressEntityManager {
	public List<AddressEntity> getAllAddress();
}
