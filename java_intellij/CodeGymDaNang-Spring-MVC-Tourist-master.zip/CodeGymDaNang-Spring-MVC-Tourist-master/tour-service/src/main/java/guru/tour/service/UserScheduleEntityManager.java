package guru.tour.service;

import guru.tour.entity.UserScheduleEntity;

public interface UserScheduleEntityManager {

	public void saveUserScheduleEntity(UserScheduleEntity userSchedule);

}
