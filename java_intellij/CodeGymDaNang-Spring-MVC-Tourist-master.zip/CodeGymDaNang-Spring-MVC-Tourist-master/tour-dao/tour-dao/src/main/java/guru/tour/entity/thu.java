package guru.tour.entity;

public class thu {

}
