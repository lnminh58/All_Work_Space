# CodeGymDaNang-Spring-MVC-Tourist
1. Build a sample real spring MVC
