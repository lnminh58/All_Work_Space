/**
 * Created by HP on 21/10/2016.
 */
var myApp = angular.module('myApp',['ngMessages']);
myApp.controller('mainController',['$scope',function($scope){
}]);

