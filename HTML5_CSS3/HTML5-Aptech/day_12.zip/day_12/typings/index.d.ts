/// <reference path="globals/jquery/index.d.ts" />
